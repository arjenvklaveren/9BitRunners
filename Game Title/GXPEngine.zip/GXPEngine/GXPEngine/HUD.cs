﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace GXPEngine
{
    public class HUD : Canvas
    {
        MyGame myGame;

        Sprite overlay;

        Font main1Font = new Font("VCR OSD Mono", 22);
        Font main2Font = new Font("VCR OSD Mono", 85);

        bool canLoop = true;
        bool looping;
        bool isDelayingLoop = false;

        public float goblinPos;

        bool enableInsertCoinText = false;

        Timing blinkInsertCoinTextOn;
        Timing blinkInsertCoinTextOff;

        public HUD() : base(1520, 790, false)
        {
            myGame = (MyGame)game;
            overlay = new Sprite("overlay.png", false, false);
            //AddChild(overlay);
            overlay.alpha = 0.6f;

            blinkInsertCoinTextOn = new Timing();
            blinkInsertCoinTextOff = new Timing();
        }

        void Update()
        {
            x = -myGame.x;
            graphics.Clear(Color.Empty);           
            if (myGame.isPlaying)
            {
                graphics.DrawString("Score: " + (int)Math.Round(myGame.score, 0), main1Font, Brushes.White, 0, 0);          
                graphics.DrawString("Lives: " + myGame.player.lives, main1Font, Brushes.White, 650, 0);          
                graphics.DrawString("Highscore: 94848", main1Font, Brushes.White, 1228, 0);
            }
            else
            {
                graphics.DrawString("[SPACE] to jump, [SHIFT] to attack", main1Font, Brushes.White, 450, 440);
                if (enableInsertCoinText)
                {
                    graphics.DrawString("PRESS [ENTER] TO PLAY", main2Font, Brushes.White, 20, 300);
                }
            }

            if (canLoop)
            {
                looping = true;
                isDelayingLoop = true;
            }

            if (isDelayingLoop)
            {
                if (blinkInsertCoinTextOff.Delay(1000))
                {
                    canLoop = true;
                    isDelayingLoop = false;
                    blinkInsertCoinTextOff.canDelay = true;
                    enableInsertCoinText = false;
                }
            }

            if (looping)
            {
                canLoop = false;
                if (blinkInsertCoinTextOn.Delay(500))
                {
                    looping = false;
                    blinkInsertCoinTextOn.canDelay = true;
                    enableInsertCoinText = true;
                }
            }
        }
    }
}
