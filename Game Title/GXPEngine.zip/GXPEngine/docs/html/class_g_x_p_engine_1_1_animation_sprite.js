var class_g_x_p_engine_1_1_animation_sprite =
[
    [ "AnimationSprite", "class_g_x_p_engine_1_1_animation_sprite.html#acc0836c2e802302a4110acb459bcdb69", null ],
    [ "AnimationSprite", "class_g_x_p_engine_1_1_animation_sprite.html#a7589d60a00303ebb60e0a24769ae88a9", null ],
    [ "initializeAnimFrames", "class_g_x_p_engine_1_1_animation_sprite.html#af011b91209d69c0e2aab0f955a461a35", null ],
    [ "NextFrame", "class_g_x_p_engine_1_1_animation_sprite.html#acfbbf3c0cefeb86eab1ed5a567547177", null ],
    [ "SetFrame", "class_g_x_p_engine_1_1_animation_sprite.html#ac1814eb56833aacf3ef62a93ed714fdd", null ],
    [ "setUVs", "class_g_x_p_engine_1_1_animation_sprite.html#adb7d11dd6f8d05c37fb624a54266ce78", null ],
    [ "_cols", "class_g_x_p_engine_1_1_animation_sprite.html#afba08ba1fcf02aa3ca6d4f52367e61ec", null ],
    [ "_currentFrame", "class_g_x_p_engine_1_1_animation_sprite.html#a5737d6a0d9bcadd1e69f0ea0532ff211", null ],
    [ "_frameHeight", "class_g_x_p_engine_1_1_animation_sprite.html#a67216ef738016e91e2240cf3703ad61b", null ],
    [ "_frames", "class_g_x_p_engine_1_1_animation_sprite.html#af2967c187ede2f6682fd96f6679efbf5", null ],
    [ "_frameWidth", "class_g_x_p_engine_1_1_animation_sprite.html#aa91f87aa054de967413882773e62dd37", null ],
    [ "currentFrame", "class_g_x_p_engine_1_1_animation_sprite.html#a6b798ae687736031661d59764ccb0fb3", null ],
    [ "frameCount", "class_g_x_p_engine_1_1_animation_sprite.html#ad401433df0638d3b5bd06c0a3fd7d063", null ],
    [ "height", "class_g_x_p_engine_1_1_animation_sprite.html#abce191963ebfa78df33cb30ac305bd02", null ],
    [ "width", "class_g_x_p_engine_1_1_animation_sprite.html#a9c91d7d8f7f4683e9822b64f130a78d8", null ]
];