var class_tiled_map_parser_1_1_data =
[
    [ "ToString", "class_tiled_map_parser_1_1_data.html#ae074098212b36f81fa3171390770c110", null ],
    [ "Encoding", "class_tiled_map_parser_1_1_data.html#a57c249a1f1d3eba2ca882f5b6614f624", null ],
    [ "innerXML", "class_tiled_map_parser_1_1_data.html#a84e2fdb9919e49ac73dc5ca932ae0962", null ]
];