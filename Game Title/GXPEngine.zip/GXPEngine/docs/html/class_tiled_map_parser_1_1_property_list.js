var class_tiled_map_parser_1_1_property_list =
[
    [ "ToString", "class_tiled_map_parser_1_1_property_list.html#aa59c9cb830c4ef8009507bc3b8374990", null ],
    [ "properties", "class_tiled_map_parser_1_1_property_list.html#a51b35b7396f31e9fe5d76d15051526db", null ]
];