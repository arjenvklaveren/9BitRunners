var searchData=
[
  ['framecount_270',['frameCount',['../class_g_x_p_engine_1_1_animation_sprite.html#ad401433df0638d3b5bd06c0a3fd7d063',1,'GXPEngine::AnimationSprite']]],
  ['frequency_271',['Frequency',['../class_g_x_p_engine_1_1_sound_channel.html#a8df9e548ec167fa10bd0e8ec6b5e7c2b',1,'GXPEngine::SoundChannel']]]
];
