var searchData=
[
  ['updatemanager_187',['UpdateManager',['../class_g_x_p_engine_1_1_managers_1_1_update_manager.html',1,'GXPEngine::Managers']]]
];
