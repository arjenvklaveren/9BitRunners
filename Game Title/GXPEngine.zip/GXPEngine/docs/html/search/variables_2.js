var searchData=
[
  ['firstgid_264',['FirstGId',['../class_tiled_map_parser_1_1_tile_set.html#ad124d1f2d876c68cfef1d93a75d3e760',1,'TiledMapParser::TileSet']]]
];
