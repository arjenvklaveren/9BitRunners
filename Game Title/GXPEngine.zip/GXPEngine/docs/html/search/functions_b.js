var searchData=
[
  ['remove_239',['Remove',['../class_g_x_p_engine_1_1_game_object.html#a2259fbe1fef900a7d5527da951934efa',1,'GXPEngine::GameObject']]],
  ['removechild_240',['RemoveChild',['../class_g_x_p_engine_1_1_game_object.html#a6dd2b18321681958c92110b4b6162efc',1,'GXPEngine::GameObject']]],
  ['render_241',['Render',['../class_g_x_p_engine_1_1_game.html#a719c9ad1c9b37a46f261e98d8d4fb4f3',1,'GXPEngine.Game.Render()'],['../class_g_x_p_engine_1_1_game_object.html#a442d88867c7be365abe6d73f9de7b923',1,'GXPEngine.GameObject.Render()']]],
  ['renderwindow_242',['RenderWindow',['../class_g_x_p_engine_1_1_window.html#a610825a7ed2a81be3ab9fd7fe7e51760',1,'GXPEngine::Window']]]
];
